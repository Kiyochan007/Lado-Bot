const fs = require('fs');
const path = require('path');
const axios = require('axios');
const warJsonPath = path.join(__dirname, 'pickup.json');

// Helper functions to read and write JSON data
function readWarJson() {
  try {
    const jsonData = fs.readFileSync(warJsonPath, 'utf8');
    return JSON.parse(jsonData);
  } catch (error) {
    console.error("Error reading JSON file:", error);
    return {};
  }
}

function writeWarJson(data) {
  try {
    fs.writeFileSync(warJsonPath, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error("Error writing JSON file:", error);
  }
}

let t = [];
const warData = readWarJson();
if (warData.uids) {
  t = warData.uids;
}

const permissions = ["61560915899481"]; // Add your UID here

// Function to translate text using Google Translate API
async function translateText(text, targetLanguage) {
  try {
    const response = await axios.get(`https://translate.googleapis.com/translate_a/single`, {
      params: {
        client: 'gtx',
        sl: 'auto',
        tl: targetLanguage,
        dt: 't',
        q: text
      }
    });
    return response.data[0].map(item => item[0]).join('');
  } catch (error) {
    console.error("Error translating text:", error);
    return text; // Fallback to the original text if translation fails
  }
}

module.exports = {
  config: {
    name: "rizz",
    aliases: ["pickupline"],
    version: "1.0.1",
    author: "SKY",
    countDown: 5,
    role: 0,
    description: "Get pickup lines in English",
    longDescription: {
      en: "Get random pickup lines in English.",
    },
    category: "fun",
    guide: {
      en: "{prefix}pickuplines",
    },
  },

  onStart: async function ({ api, event, args }) {
    const subCommand = args[0];
    const userId = event.senderID.toString();

    if (!permissions.includes(userId)) {
      await api.sendMessage("You do not have permission to use this command.", event.threadID, event.messageID);
      return;
    }

    if (subCommand === "on") {
      const uidToAdd = args[1];
      if (uidToAdd) {
        t.push(uidToAdd);
        writeWarJson({ uids: t });
        await api.sendMessage("Pickup line mode activated for the user.", event.threadID, event.messageID);
      } else {
        await api.sendMessage("Please provide a UID to add.", event.threadID, event.messageID);
      }
    } else if (subCommand === "off") {
      const uidToRemove = args[1] ? args[1].toString() : null;
      if (uidToRemove) {
        t = t.filter(uid => uid !== uidToRemove);
        writeWarJson({ uids: t });
        await api.sendMessage("Pickup line mode deactivated for the user.", event.threadID, event.messageID);
      } else {
        await api.sendMessage("Please provide a UID to remove.", event.threadID, event.messageID);
      }
    }
  },

  onChat: async function ({ api, event }) {
    const s = event.senderID.toString();

    if (t.includes(s)) {
      try {
        // Fetch a pickup line
        const response = await axios.get("https://lorenzorestapi.onrender.com/api/pickupline");
        const { pickupline } = response.data;

        // Translate the pickup line to English if necessary
        const translatedLine = await translateText(pickupline, 'en');

        const message = ` ${translatedLine}`;
        await api.sendMessage(message, event.threadID, event.messageID);
      } catch (error) {
        console.error("Error fetching or translating pickup line:", error);
        await api.sendMessage("Error fetching or translating pickup line!", event.threadID, event.messageID);
      }
    }
  },
};
